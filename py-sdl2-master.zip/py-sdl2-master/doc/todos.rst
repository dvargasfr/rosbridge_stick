Todo list for PySDL2
====================

General
-------
* more unit tests

Windows
-------
* Add support for SDL_SetWindowsMessageHook()
* Add SDL_TOUCH_MOUSEID constant